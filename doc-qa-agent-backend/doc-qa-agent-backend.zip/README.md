# Document Q&A Agent

An AI agent built with **LangGraph** that answers questions about a single
source document (`data/sample_document.pdf`), maintains conversation memory
across turns, and autonomously calls a **web search tool** only when the
document doesn't contain the answer.

## Features

- **LangGraph workflow**: `retrieve -> decide_tool -> (tool_exec ->) generate`
- **Google Gemini API** (`gemini-2.5-flash`) for chat completion, and
  Gemini's embedding model for document retrieval
- **Conversation memory** via LangGraph checkpointing (per-session thread)
- **Document retrieval** via a FAISS vector store built from the source
  document
- **One autonomous tool** (web search) — the model decides per-turn whether
  it's needed; it is never called for questions the document already answers
- **FastAPI** HTTP API with dependency injection, structured logging, and
  typed error handling
- **Docker** support for containerized deployment

## Project layout
app/
├── api/ FastAPI app, routes, request/response schemas, DI providers
├── core/ Config, logging, exception handling (infrastructure layer)
├── graph/ LangGraph state, nodes, edges, prompts, and graph builder
├── llm/ Gemini chat model client factory
├── memory/ Checkpointer factory, session/thread id management
├── retrieval/ Document loading, chunking, embeddings, FAISS vector store
├── tools/ The single web search tool
└── models.py Framework-agnostic domain models

data/ Source document + sample questions/responses for eval
docs/ Setup and deployment guides
scripts/ CLI ingestion script
tests/ Unit and integration tests

See `docs/local_setup.md` for a full development setup walkthrough and
`docs/deployment.md` for running this in Docker/production.

## Quickstart

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Configure environment
cp .env.example .env
# edit .env and set GOOGLE_API_KEY (get one at https://aistudio.google.com/apikey)
# and optionally TAVILY_API_KEY

# 3. Build the retrieval index from the sample document
python scripts/run_ingest.py

# 4. Run the API
uvicorn app.api.main:app --reload
```

Then send a message:

```bash
curl -X POST http://localhost:8000/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "What is the battery life of the Aurora M1?"}'
```

The response includes `session_id` — pass it back on subsequent requests to
continue the same conversation with full memory:

```bash
curl -X POST http://localhost:8000/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "And how heavy is it unloaded?", "session_id": "<id from previous response>"}'
```

## API endpoints

| Method | Path | Purpose |
|---|---|---|
| `POST` | `/chat` | Send a message, get the agent's answer, sources, and whether the tool was used |
| `GET` | `/health` | Liveness check |
| `GET` | `/health/ready` | Readiness check — 200 only once the vector store is loaded |

## Testing

```bash
pytest
```

Tests run fully offline against fakes for the chat model, embeddings, and
web search — no API keys or network access are required to run the suite.

## Sample document & eval material

`data/sample_document.pdf` describes a fictional company, **Aurora
Robotics**, and its warehouse robot, the **Aurora M1**. `data/
sample_questions.md` and `data/sample_responses.md` provide a set of
questions split into "answerable from the document" and "requires the web
search tool," along with expected `tool_used` values — useful for manually
verifying the router's tool-decision behavior after any prompt change.

## Design documentation

The full architecture — LangGraph workflow, state design, memory design,
retrieval flow, tool-decision flow, and diagrams — was designed before
implementation and is available on request as `PHASE_1_ARCHITECTURE.md`.