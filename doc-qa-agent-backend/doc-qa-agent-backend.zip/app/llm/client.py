"""
Factory for Gemini-backed LangChain chat models.

Centralizing model construction (SRP) means every node gets a consistently
configured client, and swapping providers/models later touches one file —
this is exactly that swap: OpenAI -> Google Gemini, with the rest of the
graph/API layers untouched since they only depend on the `BaseChatModel`
interface returned here.
"""

from __future__ import annotations

from functools import lru_cache

from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.tools import BaseTool
from langchain_google_genai import ChatGoogleGenerativeAI

from app.core.config import settings


@lru_cache(maxsize=1)
def get_chat_model() -> BaseChatModel:
    """Return a cached, configured Gemini chat model instance."""
    return ChatGoogleGenerativeAI(
        model=settings.chat_model_name,
        temperature=settings.llm_temperature,
        google_api_key=settings.google_api_key,
        timeout=30,
        max_retries=2,
    )


def bind_tools_to_model(
    model: BaseChatModel, tools: list[BaseTool]
) -> BaseChatModel:
    """Return a copy of `model` with function-calling tools bound.

    Kept as a standalone function (rather than inlined in a node) so any
    node that needs a tool-aware model uses the exact same binding logic.
    Unchanged by the provider migration — `bind_tools` is a standard
    LangChain `BaseChatModel` method that `ChatGoogleGenerativeAI` also
    implements, so no caller of this function needed to change.
    """
    return model.bind_tools(tools)